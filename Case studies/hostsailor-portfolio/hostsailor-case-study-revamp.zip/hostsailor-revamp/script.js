(function(){
  var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // Stagger index for grid children (impact cards, accessibility grid, etc.)
  document.querySelectorAll(".stagger").forEach(function(group){
    Array.prototype.forEach.call(group.children, function(child, i){
      child.style.setProperty("--i", i);
    });
  });

  // Prepare icon stroke-draw animation
  function prepIcons(){
    document.querySelectorAll("svg.ic path, svg.ic circle, svg.ic rect, svg.ic line").forEach(function(p){
      try{
        var len = p.getTotalLength ? p.getTotalLength() : 40;
        p.style.strokeDasharray = len;
        p.style.strokeDashoffset = reduced ? 0 : len;
      }catch(e){}
    });
  }
  prepIcons();

  function drawIcons(scope){
    scope.querySelectorAll("svg.ic path, svg.ic circle, svg.ic rect, svg.ic line").forEach(function(p){
      p.style.strokeDashoffset = 0;
    });
  }

  // Reveal on scroll
  var observer = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(entry.isIntersecting){
        entry.target.classList.add("visible");
        drawIcons(entry.target);
        observer.unobserve(entry.target);
      }
    });
  },{threshold:.12});
  document.querySelectorAll(".reveal").forEach(function(el){ observer.observe(el); });

  // Non-.reveal icon groups (impact/accessibility articles without the reveal class wrapper)
  var iconObserver = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(entry.isIntersecting){ drawIcons(entry.target); iconObserver.unobserve(entry.target); }
    });
  },{threshold:.2});
  document.querySelectorAll(".product-list>div, .engineering-grid article, .trust-mock, .arch-flow").forEach(function(el){
    iconObserver.observe(el);
  });

  if(reduced){
    document.querySelectorAll("svg.ic path, svg.ic circle, svg.ic rect, svg.ic line").forEach(function(p){
      p.style.strokeDashoffset = 0;
    });
  }

  // Count-up stats
  var counters = document.querySelectorAll("[data-count]");
  function animateCount(el){
    var target = parseFloat(el.dataset.count);
    var suffix = el.dataset.suffix || "";
    var duration = 1100, startTime = null;
    function step(ts){
      if(!startTime) startTime = ts;
      var progress = Math.min((ts-startTime)/duration,1);
      var eased = 1 - Math.pow(1-progress,3);
      el.textContent = Math.floor(eased*target) + suffix;
      if(progress<1) requestAnimationFrame(step); else el.textContent = target + suffix;
    }
    requestAnimationFrame(step);
  }
  if(counters.length){
    if(reduced){
      counters.forEach(function(c){ c.textContent = c.dataset.count + (c.dataset.suffix||""); });
    } else {
      var cio = new IntersectionObserver(function(entries){
        entries.forEach(function(e){
          if(e.isIntersecting){ animateCount(e.target); cio.unobserve(e.target); }
        });
      },{threshold:.5});
      counters.forEach(function(c){ cio.observe(c); });
    }
  }

  // Subtle parallax tilt on the hero product preview card
  if(!reduced){
    var browser = document.querySelector(".browser-card");
    if(browser){
      window.addEventListener("mousemove", function(ev){
        var cx = window.innerWidth/2, cy = window.innerHeight/2;
        var rx = ((ev.clientY-cy)/cy)*1.5;
        var ry = ((ev.clientX-cx)/cx)*-2;
        browser.style.transform = "perspective(1400px) rotateX("+rx+"deg) rotateY("+(ry+1)+"deg)";
      },{passive:true});
    }
  }

  // Smooth scroll for in-page links
  document.querySelectorAll('a[href^="#"]').forEach(function(a){
    a.addEventListener("click", function(e){
      var t = document.querySelector(a.getAttribute("href"));
      if(t){ e.preventDefault(); t.scrollIntoView({behavior: reduced ? "auto" : "smooth", block:"start"}); }
    });
  });
})();
